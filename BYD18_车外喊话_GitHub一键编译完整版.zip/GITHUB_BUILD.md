# iPhone 在线编译说明
把本工程上传到 GitHub 后，在 Actions 中运行 Build APK。
注意：工程需要包含 Gradle Wrapper（gradlew、gradlew.bat、gradle/wrapper/*）。如果仓库提示没有 gradlew，请用 Android Studio/Gradle 先生成 wrapper，或让我继续整理成完整 wrapper 工程。
