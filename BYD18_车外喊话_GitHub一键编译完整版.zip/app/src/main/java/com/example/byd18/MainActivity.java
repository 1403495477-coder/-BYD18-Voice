package com.example.byd18;

import android.Manifest;
import android.app.Activity;
import android.os.Bundle;
import android.content.pm.PackageManager;
import android.media.*;
import android.view.*;
import android.widget.*;

public class MainActivity extends Activity {
    AudioRecord recorder;
    AudioTrack player;
    volatile boolean running=false;
    Thread audioThread;
    int sampleRate=48000;
    SeekBar volume;
    TextView status;

    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        setContentView(com.example.byd18.R.layout.activity_main);
        status=findViewById(R.id.status);
        volume=findViewById(R.id.volume);
        Button start=findViewById(R.id.start), stop=findViewById(R.id.stop);
        if(checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO},10);
        start.setOnClickListener(v->startTalk());
        stop.setOnClickListener(v->stopTalk());
    }

    void startTalk(){
        if(running) return;
        int min=AudioRecord.getMinBufferSize(sampleRate,AudioFormat.CHANNEL_IN_MONO,AudioFormat.ENCODING_PCM_16BIT);
        recorder=new AudioRecord(MediaRecorder.AudioSource.MIC,sampleRate,AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT,min*2);
        player=new AudioTrack(AudioManager.STREAM_MUSIC,sampleRate,AudioFormat.CHANNEL_OUT_MONO,
                AudioFormat.ENCODING_PCM_16BIT,min*2,AudioTrack.MODE_STREAM);
        player.setVolume(volume.getProgress()/100f);
        recorder.startRecording(); player.play(); running=true;
        status.setText("正在喊话");
        audioThread=new Thread(()->{
            byte[] buf=new byte[min];
            while(running){
                int n=recorder.read(buf,0,buf.length);
                if(n>0) player.write(buf,0,n);
            }
        }); audioThread.start();
    }

    void stopTalk(){
        running=false;
        try{ if(recorder!=null) recorder.stop(); }catch(Exception ignored){}
        try{ if(player!=null) player.stop(); }catch(Exception ignored){}
        status.setText("已停止");
    }

    @Override protected void onDestroy(){ stopTalk(); super.onDestroy(); }
}
